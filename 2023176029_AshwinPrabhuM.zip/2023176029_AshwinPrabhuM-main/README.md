# DTI_GraphTransformer_Final

Dataset:  https://www.kaggle.com/datasets/blk1804/kiba-drug-binding-dataset

Dataset used here is KIBA dataset. The same can be accessed via the above link
